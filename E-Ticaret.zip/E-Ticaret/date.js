let date = new Date();

let month = date.getMonth();
let day = date.getDay();

// console.log(day)

let listMonth = ["JANUARY","FEBRUARY","MARCH","APRİL","MAY",
"JUNE","JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER"];

let monthName = listMonth[month];

// console.log(monthName)

let listDay = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]

let dayName = listDay[day];

// console.log(dayName)

let whichDay = date.getDate();

// console.log(whichDay)

document.getElementById("month").innerHTML = monthName;

document.getElementById("day").innerHTML += `${whichDay}  ${dayName}`;