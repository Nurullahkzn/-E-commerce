const apiURL = 'https://fakestoreapi.com/'




let startIndex = 0


async function getProducts () {
    let result = await fetch(`${apiURL}products/`)
    let products = await result.json()

    document.getElementById('photo').src = products[startIndex].image
    document.getElementById('productHead').innerHTML = products[startIndex].title
    document.getElementById('newPrice').innerHTML =`${products[startIndex].price}$` 
    document.getElementById('oldPrice').innerHTML = `${products[startIndex].price + 25.01}$`
    document.getElementById('productDescription').innerHTML = products[startIndex].description

}
getProducts()


function next(){
    startIndex++;
    getProducts()
    if(startIndex==21){
        startIndex=0;
    }
}
function prev(){
    startIndex--;
    getProducts()
    if(startIndex<=0){
        startIndex=20;
    }
}
