// const apiURL = 'https://fakestoreapi.com/'


// async function getProducts(){
//     let result = await fetch(`${apiURL}products/`)
//     let products = await result.json()


//     document.getElementById('categories').innerHTML = products.categories
//     // for(let index=0 ; i<5 ; index++){
//     //     document.getElementById('categories').innerHTML = `${category}<br>`
//     // }

// }
// getProducts()

const apiURL = 'https://fakestoreapi.com/'

// DOM elements
const categoriesEl = document.querySelector('.categories')


// methods
async function getCategories () {
  let result = await fetch(`${apiURL}products/categories`)
  let categories = await result.json()

  categories.forEach((category) => {
    categoriesEl.innerHTML += `
    <div class="categories"> &nbsp;&nbsp; ${category[0].toUpperCase() + category.slice(1).toLowerCase() }</div>
    `
  })
}
getCategories()

// var cumle=document.getElementById("cumle").value;
// document.getElementById("yaz").innerHTML = cumle[0].toUpperCase() + cumle.slice(1).toLowerCase(); 