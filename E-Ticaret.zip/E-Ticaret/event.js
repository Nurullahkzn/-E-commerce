// const apiURL = 'https://fakestoreapi.com/'

// const productsEl = document.querySelector('.sampleProducts')


// async function getEventProducts () {
//     let result = await fetch(`${apiURL}products/`)
//     let products = await result.json()

//     let newProdutcsEvent = products.slice(12,16)
//     console.log(newProdutcsEvent)

//     newProdutcsEvent.forEach((product) => {
//         productsEl.innerHTML += `
//         <div class="sampleProducts">
//          <div class="sampleProductsItem">${product.title}</div>
//          <br>
//          <div class="sampleProductsItem"">${product.price+25.01}$</div>
//          <br> 
//          <div class="sampleProductsItem">${product.price}</div>
         
//          </div>
//         `
//     })
// }
// getEventProducts()
